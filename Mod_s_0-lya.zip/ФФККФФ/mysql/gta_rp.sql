-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Авг 29 2017 г., 21:28
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `gta_rp`
--

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `pID` int(11) NOT NULL AUTO_INCREMENT,
  `pName` varchar(26) NOT NULL,
  `pKey` varchar(128) NOT NULL,
  `pSex` int(1) NOT NULL,
  `pChar` int(3) NOT NULL,
  `pCash` int(20) NOT NULL,
  `pEmail` varchar(42) NOT NULL DEFAULT 'No Mail Adress',
  `pDateReg` date NOT NULL,
  `pRegIP` varchar(20) NOT NULL,
  `pLVL` int(4) NOT NULL,
  `pReferal` varchar(26) NOT NULL DEFAULT 'None',
  `pLeader` int(2) NOT NULL,
  `pMember` int(2) NOT NULL,
  `pModel` int(3) NOT NULL,
  `pRang` int(2) NOT NULL,
  `pWarnF` int(1) NOT NULL,
  `pWarnA` int(1) NOT NULL,
  `bAdmin` int(2) NOT NULL,
  `pJob` int(2) NOT NULL,
  `pVIP` int(2) NOT NULL,
  `pCoins` int(11) NOT NULL,
  `pSupport` int(2) NOT NULL,
  `pExp` int(11) NOT NULL,
  `pMute` int(11) NOT NULL,
  `pMuteT` int(11) NOT NULL,
  `pBusKey` int(5) NOT NULL,
  `pHomeKey` int(5) NOT NULL,
  PRIMARY KEY (`pID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `Name` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `level` int(2) NOT NULL,
  `password` varchar(32) NOT NULL DEFAULT 'qwerty',
  `LastCon` varchar(32) NOT NULL,
  `Postavil` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Data` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `banned`
--

CREATE TABLE IF NOT EXISTS `banned` (
  `bName` varchar(26) NOT NULL,
  `bReason` varchar(128) NOT NULL,
  `bAName` varchar(26) NOT NULL,
  `bDate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bussines`
--

CREATE TABLE IF NOT EXISTS `bussines` (
  `bID` int(11) NOT NULL AUTO_INCREMENT,
  `bEnterX` float NOT NULL,
  `bEnterY` float NOT NULL,
  `bEnterZ` float NOT NULL,
  `bExitX` float NOT NULL,
  `bExitY` float NOT NULL,
  `bExitZ` float NOT NULL,
  `bMenuX` float NOT NULL,
  `bMenuY` float NOT NULL,
  `bMenuZ` float NOT NULL,
  `bOwner` varchar(26) CHARACTER SET utf8 NOT NULL,
  `bPrice` int(11) NOT NULL,
  `bBuyPrice` int(11) NOT NULL,
  `bMoney` int(11) NOT NULL,
  `bType` int(11) NOT NULL,
  `bLic` int(11) NOT NULL,
  `bInt` int(11) NOT NULL,
  `bVirtual` int(11) NOT NULL,
  `bLock` int(11) NOT NULL,
  `bName` varchar(128) CHARACTER SET utf8 NOT NULL,
  `bProduct` int(11) NOT NULL,
  `bMenu` int(11) NOT NULL,
  `bMafia` int(11) NOT NULL,
  `bEnter` int(2) NOT NULL,
  `bMIcon` int(11) NOT NULL,
  `bTill` int(11) NOT NULL,
  `bOwned` int(1) NOT NULL,
  PRIMARY KEY (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `name_log`
--

CREATE TABLE IF NOT EXISTS `name_log` (
  `nID` int(11) NOT NULL AUTO_INCREMENT,
  `nOldName` varchar(26) NOT NULL,
  `nNewName` varchar(26) NOT NULL,
  `nDate` date NOT NULL,
  PRIMARY KEY (`nID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
