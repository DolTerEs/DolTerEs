#include <a_samp>

#define TIME_PLAYER_WALK 3000
#define TIME_PLAYER_RUN 1000

forward ActionEffect(playerid);

new PlayerEffect[MAX_PLAYERS], PlayerRun[MAX_PLAYERS], EffectTimer[MAX_PLAYERS];

public OnFilterScriptInit()
{
	return 1;
}

public OnPlayerConnect(playerid)
{
    EffectTimer[playerid] = SetTimerEx("ActionEffect", TIME_PLAYER_WALK, true, "d", playerid);
	return 1;
}

public ActionEffect(playerid)
{
    RemovePlayerAttachedObject(playerid, PlayerEffect[playerid]);
    PlayerEffect[playerid] = SetPlayerAttachedObject(playerid,9,18696,2,0.0,0.1,-0.2,-25.5000,0.0,0.0,0.10,0.3,0.15);
    if(GetPlayerSpeed(playerid) > 10 && PlayerRun[playerid] == 0)
    {
        KillTimer(EffectTimer[playerid]);
        EffectTimer[playerid] = SetTimerEx("ActionEffect", TIME_PLAYER_RUN, true, "d", playerid);
        PlayerRun[playerid] = 1;
    }
    else if(GetPlayerSpeed(playerid) < 10 && PlayerRun[playerid] == 1)
    {
        KillTimer(EffectTimer[playerid]);
        EffectTimer[playerid] = SetTimerEx("ActionEffect", TIME_PLAYER_WALK, true, "d", playerid);
        PlayerRun[playerid] = 0;
    }
}

stock GetPlayerSpeed(playerid)
{
    new Float:ST[4];
    if(IsPlayerInAnyVehicle(playerid))
    GetVehicleVelocity(GetPlayerVehicleID(playerid),ST[0],ST[1],ST[2]);
    else GetPlayerVelocity(playerid,ST[0],ST[1],ST[2]);
    ST[3] = floatsqroot(floatpower(floatabs(ST[0]), 2.0) + floatpower(floatabs(ST[1]), 2.0) + floatpower(floatabs(ST[2]), 2.0)) * 179.28625;
    return floatround(ST[3]);
}
