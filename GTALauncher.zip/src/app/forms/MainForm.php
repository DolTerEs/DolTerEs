<?php
namespace app\forms;

use gui;
use php\lang\System;
use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 

class MainForm extends AbstractForm
{


    /**
     * @event image5.click-Left 
     */
    function doImage5ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image4.click-Left 
     */
    function doImage4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event edit.click-Left 
     */
    function doEditClickLeft(UXMouseEvent $e = null)
    {    

    }

    /**
     * @event buttonAlt.action 
     */
   /* function doButtonAltAction(UXEvent $e = null)
    {    

    }*/

    /**
     * @event label4.click-Left 
     */
    function doLabel4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label5.click-Left 
     */
    function doLabel5ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label3.click-Left 
     */
    function doLabel3ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label7.click-Left 
     */
    function doLabel7ClickLeft(UXMouseEvent $e = null)
    {   
    /* 
        $this->label7->visible = false;
        $this->label7->enabled = false;
        $this->progressDownload->visible = true;
        $this->label8->visible = true;
        $this->label9->visible = true;
        $this->label10->visible = true;
        $this->timer->start();*/
        if($this->dirChooser->execute())
        {
            $this->label7->visible = false;
            $this->label7->enabled = false;
            $this->progressDownload->visible = true;
            $this->label8->visible = true;
            $this->label9->visible = true;
            $this->label10->visible = true;
            $this->downloader->destDirectory = $this->dirChooser->file;  
            $this->downloader->urls = "https://files.sa-mp.com/sa-mp-0.3.7-R4-install.exe";
            $this->downloader->start();
        }
    }

    /**
     * @event label6.click-Left 
     */
    function doLabel6ClickLeft(UXMouseEvent $e = null)
    {    
        $name = $this->edit->text;
        $this->ini->set('NickName',$name,'PlayerInfo');
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $name = $this->ini->get('NickName','PlayerInfo');
        $this->edit->text = $name;   
    }
    
}
