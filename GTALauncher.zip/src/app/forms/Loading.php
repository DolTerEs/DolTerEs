<?php
namespace app\forms;

use std, gui, framework, app;


class Loading extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->timerAlt->start();
    }


    
    
}
